package com.rnsoftware.resource;

import com.rnsoftware.dto.UserDTO;
import com.rnsoftware.dto.UserDateDTO;
import com.rnsoftware.model.User;
import com.rnsoftware.payload.UserRequest;
import com.rnsoftware.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class UserResource {
    private static final Logger log = LoggerFactory.getLogger(UserResource.class);
    private final UserService userService;
    public UserResource(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(value = "/users", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<User> createUser(@RequestBody UserRequest userRequest) {
        log.info("REST Request to createUser: {}", userRequest);
        User result = userService.saveUser(userRequest);
        return ResponseEntity.ok().body(result);
    }
    @GetMapping(value = "/users/publish/date-range", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE, MediaType.TEXT_PLAIN_VALUE})
    public ResponseEntity<List<User>> publishUserListByDateRange(@RequestParam String fromDate, @RequestParam String toDate) {
        log.info("REST Request to publishUserListByDateRange: fromDate={}, toDate={}", fromDate, toDate);

        try {
            List<User> users = userService.fetchUsersByDateRange(fromDate, toDate);
            return ResponseEntity.ok(users);
        } catch (RuntimeException ex) {
            log.error("Error fetching users by date range: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping(value = "/users/fetch-all", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<List<UserDTO>> fetchAllUsers() {
        log.info("REST Request to fetchAllUsers");
        List<UserDTO> result = userService.fetchUsers();
        return ResponseEntity.ok(result);
    }
    @GetMapping("/fetch-enabled-users")
    public ResponseEntity<List<UserDTO>> fetchEnabledUsers() {
        log.info("REST Request to fetchEnabledUsers");
        List<UserDTO> result = userService.fetchEnabledUsers();
        return ResponseEntity.ok(result);
    }
    @GetMapping("fetch-disabled-users")
    public ResponseEntity<List<UserDTO>> fetchDisabledUsers() {
        log.info("REST Request to fetchDisabledUsers");
        List<UserDTO> result = userService.fetchDisabledUsers();
        return ResponseEntity.ok(result);
    }
    @GetMapping("/user-counts")
    public ResponseEntity<Map<String, Long>> getUserCounts() {
        Map<String, Long> userCounts = userService.getUserCountsByStatus();
        return ResponseEntity.ok(userCounts);
    }
    @GetMapping(value = "/users/fetch-by-date")
    public ResponseEntity<List<UserDateDTO>> fetchUsersByDateRange(
            @RequestParam("fromDate") String fromDateStr,
            @RequestParam("toDate") String toDateStr) {

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Timestamp fromDate = new Timestamp(dateFormat.parse(fromDateStr).getTime());
            Timestamp toDate = new Timestamp(dateFormat.parse(toDateStr).getTime());

            toDate.setTime(toDate.getTime() + 24 * 60 * 60 * 1000 - 1);

            List<UserDateDTO> users = userService.getUsersByDateRange(fromDate, toDate);
            return ResponseEntity.ok(users);
        } catch (ParseException e) {
            log.error("Date parsing error: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            log.error("Error fetching users: {}", e.getMessage());
            return ResponseEntity.badRequest().body(null);
        }
    }
    @GetMapping("/search")
    public List<User> searchUsers(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String mobile,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String gender) {
        log.info("REST Request to search users: {}, {}, {}, {}, {}", name, email, mobile, status, gender);
        return userService.searchUsers(name, email, mobile, status, gender);
    }
}
