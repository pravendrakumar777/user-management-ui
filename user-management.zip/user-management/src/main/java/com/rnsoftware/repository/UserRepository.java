package com.rnsoftware.repository;

import com.rnsoftware.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query(value = "SELECT * FROM user_details WHERE created_date BETWEEN :fromDate AND :toDate", nativeQuery = true)
    List<User> findUsersByDateRange(@Param("fromDate") Timestamp fromDate, @Param("toDate") Timestamp toDate);

    @Query(value = "SELECT * FROM user_details WHERE created_date BETWEEN :fromDate AND :toDate", nativeQuery = true)
    List<User> findUsersDateRange(@Param("fromDate") Timestamp fromDate, @Param("toDate") Timestamp toDate);

    List<User> findByStatus(String status);

    @Query("SELECT u FROM User u WHERE " + "(:name IS NULL OR u.name LIKE %:name%) AND " + "(:email IS NULL OR u.email LIKE %:email%) AND " + "(:mobile IS NULL OR u.mobile = :mobile) AND " + "(:status IS NULL OR u.status = :status) AND " + "(:gender IS NULL OR u.gender = :gender)")
    List<User> searchUsers(@Param("name") String name, @Param("email") String email, @Param("mobile") String mobile, @Param("status") String status, @Param("gender") String gender);
}
