package com.rnsoftware.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "user_details")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "email")
    private String email;

    @Column(name = "created_date")
    private Timestamp createdDate;

    @Column(name = "mobile")
    private String mobile;

    @Column(name = "modified_date")
    private Timestamp modifiedDate;

    @Column(name = "status")
    private String status;

    private String gender;

    public User() {}

    public User(String name, String email, Timestamp createdDate, String mobile, Timestamp modifiedDate, String status, String gender) {
        this.name = name;
        this.email = email;
        this.createdDate = createdDate;
        this.mobile = mobile;
        this.modifiedDate = modifiedDate;
        this.status = status;
        this.gender = gender;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Timestamp getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Timestamp createdDate) {
        this.createdDate = createdDate;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Timestamp getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Timestamp modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(id, user.id) && Objects.equals(name, user.name) && Objects.equals(email, user.email) && Objects.equals(createdDate, user.createdDate) && Objects.equals(mobile, user.mobile) && Objects.equals(modifiedDate, user.modifiedDate) && Objects.equals(status, user.status) && Objects.equals(gender, user.gender);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, email, createdDate, mobile, modifiedDate, status, gender);
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", createdDate=" + createdDate +
                ", mobile='" + mobile + '\'' +
                ", modifiedDate=" + modifiedDate +
                ", status='" + status + '\'' +
                ", gender='" + gender + '\'' +
                '}';
    }
}
