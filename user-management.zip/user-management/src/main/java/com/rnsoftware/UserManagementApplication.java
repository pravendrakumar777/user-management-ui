package com.rnsoftware;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementApplication.class, args);
		// Swagger UI = http://localhost:8083/swagger-ui.html

		// MVC UI = http://localhost:8083/create-user
		// All operation can on single url
	}
}
