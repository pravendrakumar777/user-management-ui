package com.rnsoftware.web;

import com.rnsoftware.resource.UserResource;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest(UserResource.class)
public class UserControllerTest {

}
